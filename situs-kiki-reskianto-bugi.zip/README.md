# Situs pribadi — Kiki Reskianto Bugi

Situs statis satu halaman. Tidak butuh server, database, atau proses build.
Cukup diunggah apa adanya.

## Isi folder

```
index.html      tampilan dan mesin situs (jarang perlu disentuh)
data.js         SELURUH ISI SITUS ADA DI SINI — ini yang Anda ubah
README.md       berkas ini
assets/
  favicon.ico          ikon tab peramban, dari logo KRB
  favicon-32.png
  apple-touch-icon.png ikon saat disimpan ke layar utama ponsel
  logo-krb.png         logo di pojok kiri atas
  potret-utama.jpg     foto di halaman depan
  foto-adat.jpg        galeri
  foto-formal.jpg      galeri
  foto-kasual.jpg      galeri
```

## Menaikkan ke GitHub Pages

1. Buat repositori baru di GitHub, beri nama `namaakun.github.io`
   (ganti `namaakun` dengan nama akun GitHub Anda). Pilih **Public**.
2. Klik **uploading an existing file**, lalu seret seluruh isi folder ini —
   termasuk folder `assets`. Klik **Commit changes**.
3. Buka **Settings → Pages**. Pada bagian *Source* pilih **Deploy from a branch**,
   branch `main`, folder `/ (root)`. Simpan.
4. Tunggu satu sampai dua menit. Situs akan hidup di `https://namaakun.github.io/`.

Setelah alamatnya jadi, isikan alamat itu ke `meta.alamatSitus` di dalam `data.js`
supaya tampilan tautan saat dibagikan di WhatsApp atau media sosial menjadi rapi.

## Mengubah isi situs

Ada dua cara. Keduanya menghasilkan hal yang sama.

**Cara pertama — lewat panel di situs.**
Buka situs Anda dan tambahkan `?edit` di belakang alamatnya, misalnya
`https://namaakun.github.io/?edit`. Panel penyuntingan terbuka di sebelah kanan.
Anda bisa mengubah teks, menambah atau menghapus karya, mengganti warna, dan
menyembunyikan bagian. Tekan **Terapkan** untuk melihat hasilnya langsung.

Perubahan itu baru tersimpan di peramban Anda sendiri. Agar berlaku untuk semua
pengunjung, tekan **Unduh data.js**, lalu ganti berkas `data.js` di GitHub dengan
berkas yang baru diunduh.

Pintasan: tekan `Ctrl + E` (atau `Cmd + E` di Mac) untuk membuka panel kapan saja.
Ingin mengembalikan tampilan ke isi `data.js` yang asli, ketik `krbReset()` di
konsol peramban.

**Cara kedua — langsung di GitHub.**
Buka `data.js`, klik ikon pensil, ubah teks di antara tanda kutip, lalu
**Commit changes**. Situs ikut berubah dalam waktu kurang dari satu menit.

## Mengganti foto

Unggah gambar baru ke folder `assets`, lalu sebut nama berkasnya di `data.js` —
pada `beranda.fotoUtama` atau pada daftar `galeri`. Ukuran yang nyaman:
foto depan sekitar 880 × 1100 piksel, foto galeri sekitar 760 × 1000 piksel.

## Catatan

- Situs ini sengaja tidak memuat data pribadi yang sensitif. Nomor telepon,
  alamat rumah, NIK, dan dokumen kependudukan tidak ditampilkan di mana pun.
  Alamat surel yang tercantum diambil dari yang sudah Anda publikasikan sendiri
  di jurnal; ganti atau kosongkan lewat `kontak.surel` bila tidak diinginkan.
- Beberapa tautan pada `kontak.tautan` sengaja dikosongkan (ORCID, GitHub).
  Tautan yang alamatnya kosong otomatis tidak ditampilkan. Isi saja saat siap.
- Warna dan ornamen ukiran bisa diatur di bagian `tampilan` dalam `data.js`.
  Setel `ornamenToraja` menjadi `false` bila ingin tampilan yang lebih polos.
